# Career XP 🚀

A gamified personal productivity dashboard for tracking habits, attendance, daily progress and goals.

## Features
- Habit tracker with daily check-ins
- Attendance records and CSV export
- Daily activity log
- XP points, levels and streaks
- Monthly progress charts
- Automatic saving in browser storage
- Download and restore a JSON backup
- Responsive layout for desktop and mobile

## Run locally
1. Download or clone this repository.
2. Open `index.html` in a modern browser.

## GitHub Pages
In the repository, open **Settings → Pages**. Choose **Deploy from a branch**, select `main` and `/ (root)`, then save.

## Data and privacy
Career XP stores its data in the browser's `localStorage`. Data does not automatically sync between browsers or devices. Use **Download backup** before clearing browser data or moving devices. Restore a previously downloaded JSON backup with **Restore backup**.

## Built with
HTML, CSS and JavaScript.

**Career XP — Build habits. Earn XP. Level up.**
